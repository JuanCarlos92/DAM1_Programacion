/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio0803;

/**
 *
 * @author jil
 */
public class Ejercicio0803 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        char tablero [][] = new char [8][8];
		char celda='0';
		
		for (int filas=0;filas<8;filas++)
		{	
			for (int columnas=0;columnas<8;columnas++)
			{
				if (columnas == 0)
				{
					if (filas%2 == 0)
					{
						// Negro
						celda = 'N';
					}
					else // Blanco
					{
						celda = 'B';
					}
				}
				else
				{
					if (celda=='B')
						celda = 'N';
					else
						celda = 'B';
				}
				
				tablero[filas][columnas] = celda;
			}
		}
		
		// Imprimimos en pantalla
		for (int filas=0;filas<8;filas++)
		{	
			for (int columnas=0;columnas<8;columnas++)
			{
			    System.out.print(tablero[filas][columnas]);	
			}
			System.out.println();
		}

    }
    
}
