/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio0601;
import java.util.Scanner;
/**
 *
 * @author jil
 */
public class Ejercicio0601 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
                Scanner entrada = new Scanner(System.in);
		float promedio = 0;
		float suma = 0;
		int mayor = 0;
		int menor = 0;
 
		int[] miArreglo = new int[10];
		for (int i = 0; i < 10; i++) {
			System.out.print("Introduzca el número en la posición " + (i) + " :");
			miArreglo[i] = entrada.nextInt();
		}
		// Ahora vamos a calcular los datos que nos piden
                
                // En primer lugar nos muestra todos los datos del array en sus posiciones
                // simultánemente vamos buscando cual es el número mayor y nos quedamos con la suma
                // para posteriormente realizar la media.
		for (int i = 0; i < miArreglo.length; i++) {
			suma += miArreglo[i];			
			if (mayor < miArreglo[i]) {
				mayor = miArreglo[i];
			}
			System.out.println(String.format("Posición [%d] Elemento: %d", i,
					miArreglo[i]));
		}
		menor = mayor;
                
		// Buscamos el menor;
		for (int i = 0; i < miArreglo.length; i++) {
			if (menor > miArreglo[i]) {
				menor = miArreglo[i];
			}
		}
                //calculamos la Media
                promedio = suma / miArreglo.length;
		
		// contar las veces que se repite cada número
		int cont;
		for (int i = 0; i < miArreglo.length; i++) {
			cont = 0;
			for (int j = i; j < miArreglo.length; j++) {
				if (miArreglo[i] == miArreglo[j]) {
					cont++;
				}
			}
			System.out.println(String.format("El número %d se repite %d veces",
					miArreglo[i], cont));
		}
                System.out.println("***Resultados de los análisis realizados***");
		System.out.println(String.format("La suma es %.2f, la media es %.2f, el mayor es %d, el menor es %d",
								suma, promedio, mayor, menor));
                System.out.println("***Fin de la aplicación***");
	}
    }
    
