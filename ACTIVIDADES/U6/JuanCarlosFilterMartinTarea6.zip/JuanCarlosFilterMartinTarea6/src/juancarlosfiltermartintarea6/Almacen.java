/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package juancarlosfiltermartintarea6;

import java.util.ArrayList;

/**
 *
 * @author Carlos
 */
public class Almacen {

    //Declaramos un arrayList del objeto Producto llamado a arrayGestion sin inicializar
    private ArrayList<Producto> inventario;
    private int controlError;

    // Constructorres
    public Almacen(ArrayList<Producto> inventario) {
        this.inventario = inventario;
        this.controlError = 0;
    }

    public Almacen() {
        this.inventario = new ArrayList<>();
        this.controlError = 0;
    }

    // Get
    public ArrayList<Producto> getInventario() {
        return inventario;
    }

    public int getControlError() {
        return controlError;
    }

    // Set
    public void setInventario(ArrayList<Producto> inventario) {
        this.inventario = inventario;
    }

    // Metodos
    public void addInventario(String dato) {
        Producto pAux = crearProducto(dato);

        if (pAux != null) {
            inventario.add(pAux);
        } else {
            controlError++;
        }
    }

    public void addInventario(ArrayList<String> listaDatos) {
        for (int i = 0; i < listaDatos.size(); i++) {
            addInventario(listaDatos.get(i));
        }
    }

    /**
     * Busca en el inventario un producto que coincida el codigo, si no hay
     * retorna null
     *
     * @param codigo
     * @return Objeto Procucto o null
     */
    public Producto findProducto(String codigo) {
        for (int i = 0; i < inventario.size(); i++) {
            if (inventario.get(i).getCodigo().equalsIgnoreCase(codigo)) {
                return inventario.get(i);
            }
        }

        return null;
    }

    /**
     * Recibe un string para dividir en 4 partes y crea un producto en base a
     * ello Orden: Codigo, Nombre, Cantidad, Descripcion
     *
     * @param datos Tipo String
     * @return objeto Producto
     */
    private Producto crearProducto(String datos) {
        Producto producto = new Producto();
        String[] split = datos.split(",");

        if (split.length == 4) {
            //Va almacenando con cada método productoAux.setCodigo... de la posicion del split
            producto.setCodigo(split[0]);
            producto.setNombre(split[1]);
            producto.setCantidad(split[2]);
            producto.setDescripcion(split[3]);
        } else {
            producto = null;
        }

        return producto;
    }
}
