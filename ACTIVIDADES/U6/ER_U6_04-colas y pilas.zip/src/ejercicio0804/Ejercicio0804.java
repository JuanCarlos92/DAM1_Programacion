/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio0804;

/**
 *
 * @author jil
 */
public class Ejercicio0804 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Pila miPila = new Pila(5);
		
		System.out.println("Vacia pila: " + miPila.vacia());
		miPila.apilar(5);	
		miPila.apilar(4);
		miPila.apilar(3);
		miPila.apilar(2);
		miPila.apilar(1);
		System.out.println("Llena pila: " + miPila.llena());
		System.out.println("Numero de elementos: " + 
                                       miPila.numElementos());
		miPila.imprimir();

    }
    
}
