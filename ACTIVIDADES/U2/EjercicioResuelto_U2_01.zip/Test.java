public class Test {
    
    public static void main(String args[]){
        
        ConversorDistancias distMillas = new ConversorDistancias(5.5,"Millas");
        System.out.println(distMillas.getDistancia()+" "+distMillas.getMedida()+" "+" equivalen a: "+distMillas.millasAKMetros());
        
        ConversorDistancias distKm = new ConversorDistancias(25000,"KMetros");
        System.out.println(distKm.getDistancia()+" "+distKm.getMedida()+" "+" equivalen a: "+distKm.kmetrosAMillas());
        
        
    }
    
}