
public class ConversorDistancias {

    private double distancia;
    private String medida;
    
    public ConversorDistancias(){
        this.distancia=0;
        this.medida=null;
    }
    
    public ConversorDistancias(double distancia, String medida){
        this.distancia=distancia;
        this.medida=medida;  
    }

    public double getDistancia() {
        return distancia;
    }

    public void setDistancia(double distancia) {
        this.distancia = distancia;
    }

    public String getMedida() {
        return medida;
    }

    public void setMedida(String medida) {
        this.medida = medida;
    }
    
    public double millasAKMetros() {
        
        double conversion=0;
        
        if(this.medida=="Millas"){
            this.medida="KMetros";
            conversion=this.distancia*1852;
            this.distancia=conversion;
        }
        else if(this.medida=="KMetros"){
            conversion=this.distancia;
        }
        
        return this.distancia;
        
    }
    
    public double kmetrosAMillas() {
        
        double conversion=0;
        
        if(this.medida=="Millas"){
            conversion=this.distancia;
        }
        else if(this.medida=="KMetros"){
            this.medida="Millas";
            conversion=this.distancia/1852;
            this.distancia=conversion;
        }
        
        return this.distancia;
        
    }
    
}