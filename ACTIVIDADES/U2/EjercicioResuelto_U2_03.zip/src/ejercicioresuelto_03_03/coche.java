/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicioresuelto_03_03;

/**
 *
 * @author FOC
 */
public class coche {
    private String Marca="";
    private String Color="";
    private int velocidad=0;
    public void setMarca(String Marca) {
        this.Marca = Marca;
    }
    public void setColor(String Color) {
        this.Color = Color;
    }
    public void setVelocidad(int velocidad) {
        this.velocidad = velocidad;
    }
    public String getMarca() {
        return Marca;
    }
    public String getColor() {
        return Color;
    }
    public int getVelocidad() {
        return velocidad;
    }
    public void aumentaVelocidad() {
        velocidad++;
    }
    public void disminuyeVelocidad() {
        velocidad--;
    }
}
