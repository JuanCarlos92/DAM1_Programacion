/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicioresuelto_03_03;

/**
 *
 * @author FOC
 */
public class EjercicioResuelto_03_03 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        coche c= new coche ();
        c.setMarca("Opel");
        c.setColor("Rojo");
        c.setVelocidad(50);
        
        System.out.println ("El coche " + c.getMarca() + " de color " + c.getColor() + " va a una velocidad de " +
                c.getVelocidad());
        c.aumentaVelocidad();
        c.aumentaVelocidad();
        c.aumentaVelocidad();
        
        System.out.println ("El coche " + c.getMarca() + " de color " + c.getColor() + " va a una velocidad de " +
                c.getVelocidad());
        c.disminuyeVelocidad();
        c.disminuyeVelocidad();
        
        System.out.println ("El coche " + c.getMarca() + " de color " + c.getColor() + " va a una velocidad de " +
                c.getVelocidad());
    }
    
}
