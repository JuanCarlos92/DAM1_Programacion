CREATE TABLE empleados
(
	id_empleado INT PRIMARY KEY,
	nombre VARCHAR(20),
	apellidos VARCHAR(20),
	trabajo VARCHAR(20),
	fecha_contratacion DATE,
	salario FLOAT(6,2)
);