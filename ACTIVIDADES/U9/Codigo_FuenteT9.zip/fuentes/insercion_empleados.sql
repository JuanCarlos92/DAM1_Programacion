INSERT INTO empleados VALUES
(1, 'Rodrigo', 'Santolaya', 'Informatico', '2008-7-07', 1850.47);
INSERT INTO empleados VALUES
(2, 'Antonio', 'Dominguez', 'Director de ventas', '2006-12-01', 2320.53);
INSERT INTO empleados VALUES
(4, 'Jose', 'Lopez', 'Recursos humanos', '2009-4-16', 1032.85);
INSERT INTO empleados VALUES
(3, 'Pedro', 'Rodriguez', 'Informatico', '2014-3-27', 1700.10);