/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pgr_u02_ejers_08;

/**
 *
 * @author jil
 */
public class PGR_U02_EJERS_08 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Evaluación de expresiones
        int n1=2, n2;
        n2= n1 * n1;
        n2 = n2 -n1;
        n2 = n2 + n1 + 15;
        n2 = n2/n1;
        n2= n2%n1;
        
        System.out.println ("El resultado de n2 es: " + n2);
                
    }
    
}
