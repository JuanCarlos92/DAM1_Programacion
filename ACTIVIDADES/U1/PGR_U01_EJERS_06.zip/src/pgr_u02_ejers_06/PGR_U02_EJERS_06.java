/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pgr_u02_ejers_06;

/**
 *
 * @author jil
 */
public class PGR_U02_EJERS_06 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int a= 5;
        int b= 2;
        int c= 4;
        int d= 8;
        
        
        int e= a* d;
        int f= b * c;
        
        System.out.println ( "El resultado de dividir " + a + "/" + b + ":" + 
                c+ "/" +d + " es la fracción --> " + e + "/" + f);
    }
    
}
