/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pgr_u02_ejers_03;

/**
 *
 * @author jil
 */
public class PGR_U02_EJERS_03 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String nombre = "Pepe";
        int edad = 25;
        
        String resultado ;
        
        resultado = nombre + edad;
        
        //System.out.println("El resultado es " + resultado );
        
        System.out.println("La edad de " + nombre + " es " + edad );
        
    }
    
}
