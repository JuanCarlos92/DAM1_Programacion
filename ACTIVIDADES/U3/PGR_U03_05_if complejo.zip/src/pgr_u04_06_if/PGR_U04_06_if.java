
package pgr_u04_06_if;

/**
 *
 * @author jil
 */
public class PGR_U04_06_if {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int a=2;
        int b=6;
        int c=3;
        double discriminante=Math.pow(b, 2)-(4*a*c);
  
        System.out.println(">>"+discriminante);
  
        if (discriminante>0){
            double x1=((b*(-1))+Math.sqrt(discriminante))/(2*a);
            double x2=((b*(-1))-Math.sqrt(discriminante))/(2*a);
  
            System.out.println("El valor de x1 es "+x1+" y el valor de x2 es "+x2);
        }else{
            System.out.println("El discriminante es negativo");
        }
    }
    
}
