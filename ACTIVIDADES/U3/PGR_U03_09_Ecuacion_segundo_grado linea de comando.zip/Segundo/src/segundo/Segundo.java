package segundo;

public class Segundo {

  public static void main(String[] args) {
    //Obtenemos los parametros
    String parametro1 = args[0];
    String parametro2 = args[1];
    String parametro3 = args[2];
    
    //Convertimos los parametros a enteros
    //La función parseInt convierte un String a un int
    int a = Integer.parseInt(parametro1);
    int b = Integer.parseInt(parametro2);
    int c = Integer.parseInt(parametro3);
    
    //Resolvemos la ecuación
    //La función sqrt realiza la raiz cuadrada
    double raiz = Math.sqrt(b*b - 4*a*c);
    double numeradorSumando = -b + raiz;
    double numeradorRestando = -b - raiz;
    int denominador = 2*a;
    
    double solucion1 = numeradorSumando/denominador;
    double solucion2 = numeradorRestando/denominador;
    
    System.out.println("Solucion 1= "+solucion1);
    System.out.println("Solucion 2= "+solucion2);
  }
}


