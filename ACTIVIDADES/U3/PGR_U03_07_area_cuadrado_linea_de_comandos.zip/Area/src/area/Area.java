package area;

public class Area {

  public static void main(String[] args) {
    //Recogemos el parámetro
    String parametro = args[0];
    
    //Con esta función convertimos el parámetro en string a un entero
    int lado = Integer.parseInt(parametro);
    
    //Calculamos el area
    int area = lado * lado;
    
    //Mostramos el resultado por pantalla
    System.out.println("El area del cuadrado es "+area);
  }
}


