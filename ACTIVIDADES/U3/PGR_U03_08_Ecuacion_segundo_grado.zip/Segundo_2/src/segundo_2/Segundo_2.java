package segundo_2;

public class Segundo_2 {
  
  public static void main(String[] args) {
    double a = 15;
    double b = 7.3;
    double c = -1;
    
    //Resolvemos la ecuación
    //La función sqrt realiza la raiz cuadrada
    double raiz = Math.sqrt(b*b - 4*a*c);
    double numeradorSumando = -b + raiz;
    double numeradorRestando = -b - raiz;
    double denominador = 2*a;
    
    double solucion1 = numeradorSumando/denominador;
    double solucion2 = numeradorRestando/denominador;
    
    System.out.println("Solucion 1= "+solucion1);
    System.out.println("Solucion 2= "+solucion2);
  }
}

