package main;

import animales.*;

public class Main
{
  public static void main(String[] args)
  {
    Mamifero m = new Mamifero();
    Ave a = new Ave();
    
    System.out.println("El mamífero puede " + m.accion() + "\n");
    System.out.println("El ave puede " + a.accion() + "\n");
  }
}
