package animales;

public class Mamifero
{
  public String accion()
  {
    return "andar, volar o nadar";
  }
}
