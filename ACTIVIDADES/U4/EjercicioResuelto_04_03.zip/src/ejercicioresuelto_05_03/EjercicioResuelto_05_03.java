/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicioresuelto_05_03;

/**
 *
 * @author FOC
 */
public class EjercicioResuelto_05_03 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        claseAlumno ca = new claseAlumno();
        claseAlumno ca1 = new claseAlumno(10,"Juan",42);
        System.out.println("Nombre del Primer alumno: " + ca.getNombre() + "  Edad: " + ca.getEdad() + " la nota es: " + ca.getNota());
        System.out.println("Nombre del Segundo Alumno: " + ca1.getNombre() + "  Edad: " + ca1.getEdad()+ " la nota es: " + ca1.getNota());        
    }
    
}
