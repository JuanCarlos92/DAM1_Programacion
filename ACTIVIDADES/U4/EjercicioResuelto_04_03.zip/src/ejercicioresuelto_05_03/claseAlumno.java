/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicioresuelto_05_03;

/**
 *
 * @author FOC
 */
public class claseAlumno extends clasePersona {
    int nota;

    public claseAlumno() {
        super("",0);
        this.nota = 0;
    }

    public claseAlumno(int nota, String nombre, int edad) {
        super(nombre, edad);
        this.nota = nota;
    }

    public int getNota() {
            return nota;
    }
    
    public void setNota(int nota) {
            this.nota=nota;
    }
    
    
}
