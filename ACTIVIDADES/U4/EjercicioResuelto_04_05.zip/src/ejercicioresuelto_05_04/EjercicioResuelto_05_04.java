/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicioresuelto_05_04;

/**
 *
 * @author FOC
 */
public class EjercicioResuelto_05_04 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        claseCoche co = new claseCoche();
        claseCoche co1 = new claseCoche(1000,"Renaul",23000);
        System.out.println("Marca Primer coche: " + co.getMarca() + "  Precio: " + co.getPrecio() + " la cilindrada es: " + co.getCilindrada());
        System.out.println("Marca Segundo coche: " + co1.getMarca() + "  Precio: " + co1.getPrecio() + " la cilindrada es: " + co1.getCilindrada());
    }
    
}
