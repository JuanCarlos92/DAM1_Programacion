/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicioresuelto_05_04;

import vehiculos.claseVehiculo;

/**
 *
 * @author FOC
 */
public class claseCoche extends claseVehiculo {
    int cilindrada;

    public claseCoche(int cilindrada, String marca, int precio) {
        super(marca, precio);
        this.cilindrada = cilindrada;
    }

    public claseCoche() {
        super ("",0);
        cilindrada=0;
    }
    
    public int getCilindrada() {
        return cilindrada;
    }
    
    public void setCilindrada(int cilindrada) {
        this.cilindrada = cilindrada;
    }
    
    
}
