package animales;

public class Tigre extends Mamifero
{
  
}
