package animales;

public class Ave
{
  public String accion()
  {
    return "volar";
  }
}
