package animales;

public class Lobo extends Mamifero
{
  
}
