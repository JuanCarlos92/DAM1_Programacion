/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicioresuelto_05_04;

/**
 *
 * @author FOC
 */
public class claseVehiculo {
    String marca;
    int precio;

    public claseVehiculo() {
        marca="";
        precio=0;
    }

    public claseVehiculo(String marca, int precio) {
        this.marca = marca;
        this.precio = precio;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public int getPrecio() {
        return precio;
    }

    public void setPrecio(int precio) {
        this.precio = precio;
    }
    
    

    
    
}
