package main;

import animales.*;

public class Main
{
  public static void main(String[] args)
  {
    Mamifero m = new Mamifero();
    Ave a = new Ave();
    Lobo l = new Lobo();
    Tigre t = new Tigre();
    
    System.out.println("El mamífero puede " + m.accion() + "\n");
    System.out.println("El ave puede " + a.accion() + "\n");
    System.out.println("El lobo puede " + l.accion() + "\n");
    System.out.println("El tigre puede " + t.accion() + "\n");
  }
}
