package animales;

public class Tigre extends Mamifero
{
  @Override
  public String accion()
  {
    return "rugir";
  }
}
