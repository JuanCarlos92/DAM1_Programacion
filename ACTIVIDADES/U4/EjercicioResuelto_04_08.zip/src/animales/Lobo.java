package animales;

public class Lobo extends Mamifero
{
  @Override
  public String accion()
  {
    return "aullar";
  }
}
