/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicioresuelto_05_02;

/**
 *
 * @author FOC
 */
public class EjercicioResuelto_05_02 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        clasePersona p1 =new clasePersona();
        clasePersona p2 =new clasePersona("Pepe",25);
        
        System.out.println("Nombre de la primera persona: " + p1.getNombre() + "  Edad: " + p1.getEdad());
        System.out.println("Nombre de la segunda persona: " + p2.getNombre() + "  Edad: " + p2.getEdad());
        
    }
    
}
