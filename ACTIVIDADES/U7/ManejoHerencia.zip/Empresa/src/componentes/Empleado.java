package componentes;

public class Empleado
{
  
}
