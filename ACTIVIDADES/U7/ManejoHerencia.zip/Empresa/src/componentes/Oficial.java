package componentes;

public class Oficial extends Operario
{
  
}

