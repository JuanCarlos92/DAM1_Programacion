package componentes;

public class Directivo extends Empleado
{
  
}

