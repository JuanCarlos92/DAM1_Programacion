package componentes;

public class Operario extends Empleado
{
  
}

