package componentes;

public class Tecnico extends Operario
{
  
}

