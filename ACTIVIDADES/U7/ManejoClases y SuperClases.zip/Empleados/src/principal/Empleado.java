package principal;

public class Empleado
{
  private final int idEmpleado;
  private final String nombre;
  private double sueldo;
  private static int numeroDeEmpleados = 0;
  
  public Empleado(int idEmpleado, String nombre, double sueldo)
  {
    this.idEmpleado = idEmpleado;
    this.nombre = nombre;
    this.sueldo = sueldo;
    
    numeroDeEmpleados++;
  }
  
  public int getID()
  {
    return idEmpleado;
  }
  
  public String getNombre()
  {
    return nombre;
  }
  
  public double getSueldo()
  {
    return sueldo;
  }
  
  public static int getNumEmpleados()
  {
    return numeroDeEmpleados;
  }
  
  public void aumentarSueldo(int porcentaje)
  {
    sueldo += sueldo * porcentaje / 100;
  }
}

