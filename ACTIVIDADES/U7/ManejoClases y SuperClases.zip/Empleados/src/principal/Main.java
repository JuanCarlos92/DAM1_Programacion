package principal;

public class Main
{
  public static void main(String[] args)
  {
    Jefe luis = new Jefe(0, "Luis", 10000, 500000);
    Empleado pepe = new Empleado(3, "Pepe", 2500);
    Empleado lidia = new Empleado(5, "Lidia", 2500);
    
    System.out.print("ID: " + luis.getID() + "\nNombre: " + 
            luis.getNombre() + "\nSueldo: " + luis.getSueldo()
            + "\nPresupuesto: " + luis.getPresupuesto() + 
            "\nNumero de jefes: " + Jefe.getNumJefes() + 
            " Numero de empleados: " + Jefe.getNumEmpleados() + "\n");
  }
}


