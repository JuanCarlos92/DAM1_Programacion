package principal;

public class Voladores
{
  public static void main(String[] args)
  {
    Superman sp = new Superman();
    
    sp.despegar();
    sp.volar();
    sp.aterrizar();
    sp.comer();
  }
}
