package principal;

public class Kriptoniano extends Animal
{
  
}
