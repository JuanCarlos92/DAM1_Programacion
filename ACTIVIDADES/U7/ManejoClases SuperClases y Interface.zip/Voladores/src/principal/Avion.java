package principal;

public class Avion extends Vehiculo implements ObjetoVolador
{
  @Override
  public void despegar()
  {
    System.out.print("Despegando desde la clase " 
            + this.getClass() + "\n");
  }

  @Override
  public void aterrizar()
  {
    System.out.print("Aterrizando desde la clase " 
            + this.getClass() + "\n");
  }

  @Override
  public void volar()
  {
    System.out.print("Volando desde la clase " 
            + this.getClass() + "\n");
  }
}
