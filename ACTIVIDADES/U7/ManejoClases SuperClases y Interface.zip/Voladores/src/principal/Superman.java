package principal;

public class Superman extends Kriptoniano implements ObjetoVolador
{
  @Override
  public void despegar()
  {
    System.out.print("Despegando desde la clase " +
            this.getClass() + "\n");
  }

  @Override
  public void aterrizar()
  {
    System.out.print("Aterrizando desde la clase " +
            this.getClass() + "\n");
  }

  @Override
  public void volar()
  {
    System.out.print("Volando desde la clase " +
            this.getClass() + "\n");
  }
  
  public void saltarEdificio()
  {
    System.out.print("Saltando desde la clase " +
            this.getClass() + "\n");
  }
  
  public void detenerBala()
  {
    System.out.print("Deteniendo bala desde la clase "
            + this.getClass() + "\n");
  }
}

