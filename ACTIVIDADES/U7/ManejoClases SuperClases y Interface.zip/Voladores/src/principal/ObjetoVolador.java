package principal;

public interface ObjetoVolador
{
  public void despegar();
  public void aterrizar();
  public void volar();
}

