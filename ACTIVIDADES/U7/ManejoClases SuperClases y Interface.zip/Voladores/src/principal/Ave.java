package principal;

public class Ave extends Animal implements ObjetoVolador
{
 @Override
  public void despegar()
  {
    System.out.print("Despegando desde la clase " 
            + this.getClass() + "\n");
  }

  @Override
  public void aterrizar()
  {
    System.out.print("Aterrizando desde la clase " 
            + this.getClass() + "\n");
  }

  @Override
  public void volar()
  {
    System.out.print("Volando desde la clase " 
            + this.getClass() + "\n");
  }
  
  public void hacerNido()
  {
    System.out.print("Haciendo nido desde la clase " 
            + this.getClass() + "\n");
  }
  
  public void ponerHuevos()
  {
    System.out.print("Poniendo huevos desde la clase "
            + this.getClass() + "\n");
  }
}

