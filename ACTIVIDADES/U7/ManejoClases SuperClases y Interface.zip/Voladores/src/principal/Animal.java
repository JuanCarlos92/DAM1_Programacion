package principal;

public class Animal
{
  public void comer()
  {
    System.out.print("Comiendo desde la clase: " 
            + this.getClass() + "\n");
  }
}

