package personal;

public class Profesor extends Persona
{
  private String asignatura;

  public Profesor(String nombre, String DNI, String asignatura)
  {
    super(nombre, DNI);
    this.asignatura = asignatura;
  }
  
  @Override
  public void baja()
  {
    super.baja();
    this.asignatura = null;
  }
  
  public void modificacion(String nombre, String DNI, String asignatura)
  {
    super.modificacion(nombre, DNI);
    this.asignatura = asignatura;
  }
}

