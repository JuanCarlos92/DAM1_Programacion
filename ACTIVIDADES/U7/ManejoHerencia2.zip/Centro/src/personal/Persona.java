package personal;

public class Persona
{
  private String nombre;
  private String DNI;
  
  public Persona(String nombre, String DNI)
  {
    this.nombre = nombre;
    this.DNI = DNI;
  }
  
  public void baja()
  {
    this.nombre = null;
    this.DNI = null;
  }
  
  public void modificacion(String nombre, String DNI)
  {
    this.nombre = nombre;
    this.DNI = DNI;
  }
}

