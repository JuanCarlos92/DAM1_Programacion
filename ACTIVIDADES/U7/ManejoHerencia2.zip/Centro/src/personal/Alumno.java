package personal;

public class Alumno extends Persona
{
  private String curso;
  
  public Alumno(String nombre, String DNI, String curso)
  {
    super(nombre, DNI);
    this.curso = curso;
  }

  @Override
  public void baja()
  {
    super.baja();
    this.curso = null;
  }
  
  public void modificacion(String nombre, String DNI, String curso)
  {
    super.modificacion(nombre, DNI);
    this.curso = curso;
  }
}
