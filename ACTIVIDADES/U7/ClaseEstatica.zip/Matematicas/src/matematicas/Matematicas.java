package matematicas;

import java.util.ArrayList;

public final class Matematicas
{
  //Hacemos el constructor privado para que
  //no se puedan crear instancias de la clase.
  private Matematicas(){}
  
  public static double MaxArray(ArrayList<Double> array)
  {
    double max = -10000000;
    
    for(int i = 0; i < array.size(); i++)
    {
      if(max < array.get(i))
        max = array.get(i);
    }
    
    return max;
  }
  
  public static double MinArray(ArrayList<Double> array)
  {
    double min = 10000000;
    
    for(int i = 0; i < array.size(); i++)
    {
      if(min > array.get(i))
        min = array.get(i);
    }
    
    return min;
  }
  
  public static double SumArray(ArrayList<Double> array)
  {
    double sum = 0;
    
    for(int i = 0; i < array.size(); i++)
        sum += array.get(i);
    
    return sum;
  }
}

