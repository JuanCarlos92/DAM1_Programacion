
package implementacion_metodos_clase_rectangulo;


public class Rectangulo {
   
    private int base; //Atributo que representa la base del rectángulo
    private int altura; //Atributo que representa la altura del rectángulo

    //Definición del método área del rectángulo
    public int area(){
        return base*altura;
    }
}

