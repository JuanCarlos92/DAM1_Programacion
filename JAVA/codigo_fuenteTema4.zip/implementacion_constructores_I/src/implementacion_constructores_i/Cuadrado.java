
package implementacion_constructores_i;


public class Cuadrado {
    private double base;
    private double altura;


    public Cuadrado(double ba, double alt){
        base = ba;
        altura = alt;
    }
}
