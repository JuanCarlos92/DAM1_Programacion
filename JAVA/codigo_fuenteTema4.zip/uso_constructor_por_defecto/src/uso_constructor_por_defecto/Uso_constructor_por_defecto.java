
package uso_constructor_por_defecto;

public class Uso_constructor_por_defecto {

    public static void main(String[] args) {
        
        // Estamos usando el constructor por defecto
        Persona p = new Persona(); 
    
        p.imprimir();
    }
}


