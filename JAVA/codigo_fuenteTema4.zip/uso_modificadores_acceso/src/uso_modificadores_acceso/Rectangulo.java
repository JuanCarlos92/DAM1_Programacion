
package uso_modificadores_acceso;

public class Rectangulo {

    private int base; //Atributo que representa la base del rectángulo
    private int altura; //Atributo que representa la altura del rectángulo

    //Método que permite asignar un valor al atributo base del rectangulo
    public void setBase (int b){
            base = b;
    }
    //Método que permite asignar un valor al atributo altura del triángulo
    public void setAltura (int a){
            altura = a;
    }
}

