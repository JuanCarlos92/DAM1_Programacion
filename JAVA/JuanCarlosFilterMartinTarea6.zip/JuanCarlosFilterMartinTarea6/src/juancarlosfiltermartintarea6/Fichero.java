/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package juancarlosfiltermartintarea6;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author Juan Carlos
 */
public class Fichero {

    //Declaramos un arrayList del objeto Producto llamado a arrayGestion sin inicializar
    private ArrayList<Producto> arrayGestion;
    //Creamos la ruta con una constante
    final private String archivo = "productos.txt";
    //Variable contador para controlar si hay errores
    private int controlError = 0;

    public ArrayList<Producto> getarrayGestion() {
        return arrayGestion;
    }

    public void leerFichero() {

        try {
            //Inicializamos el arrayList con new (arrayGestion es un nuevo arraylist)
            arrayGestion = new ArrayList<>();

            //Nuevo objeto fichero de la clase File pasandole la ruta
            File fichero = new File(archivo);

            //Si el fichero no existe lo crea
            if (!fichero.exists()) {
                fichero.createNewFile();
            }

            //Objetos de la clase FileReader y BufferedReader para poder usar el manejo de lectura de ficheros.
            FileReader fd = new FileReader(fichero);
            BufferedReader bf = new BufferedReader(fd);

            //Variable String linea donde se va a almacenar cada linea leida
            String linea;

            //do while -> Para que entre almenos una vez al bucle sin importar la condición
            do {
                //Nuevo objeto de la clase Producto (en cada vuelta se vuelve a inicializar)
                Producto productoAux = new Producto();
                //Almacenamos la linea leida en la variable
                linea = bf.readLine();

                //Si linea es diferente a null entra... hace un split separando por "," y...
                if (linea != null) {
                    String[] split = linea.split(",");
                    //Va almacenando con cada método productoAux.setCodigo... de la posicion del split
                    productoAux.setCodigo(split[0]);
                    productoAux.setNombre(split[1]);
                    productoAux.setCantidad(split[2]);
                    productoAux.setDescripcion(split[3]);
                    //Almacena el objeto productoAux con todas su variables al arrayGestion y guarda esa linea con el formato ToString de la clase Producto
                    arrayGestion.add(productoAux);
                }

                //Comprueba si linea es diferente a null si aun contiene linea... vuelve al inicio del do
            } while (linea != null);
            bf.close();

        } catch (IOException ex) {
            JOptionPane.showMessageDialog(null, "SE HA PRODUCIDO UN ERROR",
                    "ERROR", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void insertarProducto(String codigo, String nombre, String cantidad, String descripcion) {
        //Nuevo objeto fichero de la clase File pasandole la ruta
        File fichero = new File(archivo);

        erroresInsertar(codigo, nombre, cantidad, descripcion);

        try {
            if (this.controlError == 0) {

                //Si el fichero no existe lo crea
                if (!fichero.exists()) {
                    fichero.createNewFile();
                }
                //Objeto de la clase FileWrite para poder escribir en el fichero y true para lo haga a continuacón sin borrar el contenido.
                FileWriter fw = new FileWriter(fichero, true);
                //Se escribe el 'codigo,' 'nombre,' cantidad,' descripcion,' recogido de los parámetros del método 
                fw.write(codigo + ",");
                fw.write(nombre + ",");
                fw.write(cantidad + ",");
                fw.write(descripcion + ",");
                //seguido de un salto de línea
                fw.write("\n");

                fw.close();

                JOptionPane.showMessageDialog(null, "Se ha insertador correctamente",
                        "ÉXITO", JOptionPane.INFORMATION_MESSAGE);

            }
            this.controlError = 0;

        } catch (IOException ex) {
            JOptionPane.showMessageDialog(null, "SE HA PRODUCIDO UN ERROR",
                    "ERROR", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void modificarProducto(String codigo, String nombre, String cantidad, String descripcion) {
        File fichero = new File(archivo);
        try {

            FileWriter fw = new FileWriter(fichero, true);
            fw.write(nombre + ",");
            fw.write(cantidad + ",");
            fw.write(descripcion + ",");

            fw.write("\n");

            fw.close();

        } catch (IOException ex) {
            JOptionPane.showMessageDialog(null, "SE HA PRODUCIDO UN ERROR",
                    "ERROR", JOptionPane.ERROR_MESSAGE);
        }
    }

    public void erroresInsertar(String codigo, String nombre, String cantidad, String descripcion) {
        //Variable msgError que esté vacío para más adelante controlar los diferentes errores 
        String msgError = null;
        //Variable contador para que posteriormente si entra en algun if de error a este se le sume 1
        int contador = 0;
        try {

            //Control de posibles errores, si cualquier textField está vacío... entra a su if, guarda la cadena de texto en la variable msgError
            if (codigo == null || codigo.equals("")) {
                msgError = "Te has dejado el CODIGO sin informar";
            } else if (nombre == null || nombre.equals("")) {
                msgError = "Te has dejado el NOMBRE sin informar";
            } else if (cantidad == null || cantidad.equals("")) {
                msgError = "Te has dejado la CANTIDAD sin informar";
            } else if (descripcion == null || descripcion.equals("")) {
                msgError = "Te has dejado la DESCRIPCIÓN sin informar";
            }

            //Si encuentra un error la variable msgError no estará vacía entro entra en el if y muestra ese mensaje en un JOptionPane
            if (msgError != null) {
                JOptionPane.showMessageDialog(null, msgError,
                        "Error", JOptionPane.ERROR_MESSAGE);
                //Sumamos en 1 contador y decimos que controlError vale contador
                contador++;
                this.controlError = contador;
                return;
            }
            //Objeto de la clase fichero con el método leerFichero

            leerFichero();
            //Bucle que va a recorrer desde 0 hasta la longitud de arrayGestion
            for (int i = 0; i < getarrayGestion().size(); i++) {
                //Si en la posicion "x" del array agarra el codigo y lo compara con el codigo de la ventana almacena la cadena de texto en msgError
                if ((getarrayGestion().get(i).getCodigo().equals(codigo))) {
                    msgError = "Este artículo ya fué insertado";
                    //Sumamos en 1 contador y decimos que controlError vale contador
                    contador++;
                    this.controlError = contador;
                }
            }
            //Si msgError no es nulo va a mostrar el error "Este artículo ya fué insertado"
            if (msgError != null) {
                JOptionPane.showMessageDialog(null, msgError,
                        "Error", JOptionPane.ERROR_MESSAGE);
                //Sumamos en 1 contador y decimos que controlError vale contador
                contador++;
                this.controlError = contador;
                return;
            }

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(null, "ERROR",
                    "ERROR", JOptionPane.ERROR_MESSAGE);
        }

    }

    public void filtrado(String codigo) {
        //Bucle que va a recorrer desde 0 hasta la longitud de arrayGestion
        for (int i = 0; i < getarrayGestion().size(); i++) {
            //Si en la posicion "x" del array agarra el codigo y lo compara con el codigo de la ventana
            if ((getarrayGestion().get(i).getCodigo().equals(codigo))) {
                
            }
        }
    }

    public void borrarProducto(String codigo) {
        //Variable msgError que esté vacío para más adelante controlar los diferentes errores 
        int selecion;
        //Bucle que va a recorrer desde 0 hasta la longitud de arrayGestion
        for (int i = 0; i < getarrayGestion().size(); i++) {
            //Si en la posicion "x" del array agarra el codigo y lo compara con el codigo de la ventana
            if ((getarrayGestion().get(i).getCodigo().equals(codigo))) {
                selecion = JOptionPane.showOptionDialog(null, "¿Estás seguro de que deseas borrar este producto?",
                        "Ventana de confirmación", JOptionPane.YES_NO_CANCEL_OPTION, JOptionPane.QUESTION_MESSAGE,
                        null, new Object[]{"SI", "NO"}, "SI");

                if (selecion != -1) {

                }
            }
        }
    }
}
