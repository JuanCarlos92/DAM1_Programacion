/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package juancarlosfiltermartintarea6;

import javax.swing.JOptionPane;

/**
 *
 * @author Juan Carlos
 */
public class JuanCarlosFilterMartin extends javax.swing.JFrame {

    Fichero f;

    public JuanCarlosFilterMartin() {
        initComponents();
        f = new Fichero();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        codigoLb = new javax.swing.JLabel();
        buscarBt = new javax.swing.JButton();
        nombreLb = new javax.swing.JLabel();
        modificarBt = new javax.swing.JButton();
        cantidadLb = new javax.swing.JLabel();
        borrarBt = new javax.swing.JButton();
        descripcionLb = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        codigoTf = new javax.swing.JTextField();
        nombreTf = new javax.swing.JTextField();
        cantidadTf = new javax.swing.JTextField();
        descripcionTf = new javax.swing.JTextField();
        insertarBt = new javax.swing.JButton();
        jPanel2 = new javax.swing.JPanel();
        listadoLb = new javax.swing.JLabel();
        mostrarBt = new javax.swing.JButton();
        salirBt = new javax.swing.JButton();
        listadoTa = new javax.swing.JScrollPane();
        listadoTextArea = new javax.swing.JTextArea();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Formulario de Gestión");
        setResizable(false);

        jPanel1.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        codigoLb.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        codigoLb.setText("Codigo");

        buscarBt.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        buscarBt.setText("BUSCAR");
        buscarBt.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        buscarBt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buscarBtActionPerformed(evt);
            }
        });

        nombreLb.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        nombreLb.setText("Nombre");

        modificarBt.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        modificarBt.setText("MODIFICAR");
        modificarBt.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        modificarBt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                modificarBtActionPerformed(evt);
            }
        });

        cantidadLb.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        cantidadLb.setText("Cantidad");

        borrarBt.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        borrarBt.setText("BORRAR");
        borrarBt.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        borrarBt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                borrarBtActionPerformed(evt);
            }
        });

        descripcionLb.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        descripcionLb.setText("Descripción");

        codigoTf.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        codigoTf.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                codigoTfActionPerformed(evt);
            }
        });

        nombreTf.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        nombreTf.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nombreTfActionPerformed(evt);
            }
        });

        cantidadTf.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N

        descripcionTf.setFont(new java.awt.Font("Segoe UI", 0, 14)); // NOI18N
        descripcionTf.setToolTipText("");

        insertarBt.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        insertarBt.setText("INSERTAR");
        insertarBt.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        insertarBt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                insertarBtActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(insertarBt, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(modificarBt, javax.swing.GroupLayout.DEFAULT_SIZE, 124, Short.MAX_VALUE))
                                .addGap(47, 47, 47)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(buscarBt, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(borrarBt, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(12, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(codigoLb)
                            .addComponent(cantidadLb)
                            .addComponent(nombreLb)
                            .addComponent(descripcionLb))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(cantidadTf, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(descripcionTf, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(nombreTf, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(codigoTf, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(50, 50, 50))))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(49, 49, 49)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(codigoTf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(codigoLb))
                .addGap(42, 42, 42)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(nombreTf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(nombreLb))
                .addGap(47, 47, 47)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cantidadLb)
                    .addComponent(cantidadTf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(52, 52, 52)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(descripcionLb)
                    .addComponent(descripcionTf, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(30, 30, 30)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(insertarBt, javax.swing.GroupLayout.DEFAULT_SIZE, 35, Short.MAX_VALUE)
                    .addComponent(buscarBt, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(modificarBt, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(borrarBt, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(15, Short.MAX_VALUE))
        );

        jPanel2.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        listadoLb.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        listadoLb.setText("Listado de productos");

        mostrarBt.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        mostrarBt.setText("MOSTRAR");
        mostrarBt.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        mostrarBt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mostrarBtActionPerformed(evt);
            }
        });

        salirBt.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        salirBt.setText("SALIR");
        salirBt.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        salirBt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                salirBtActionPerformed(evt);
            }
        });

        listadoTextArea.setColumns(20);
        listadoTextArea.setRows(5);
        listadoTa.setViewportView(listadoTextArea);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(mostrarBt, javax.swing.GroupLayout.PREFERRED_SIZE, 153, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(51, 51, 51)
                        .addComponent(salirBt, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(listadoLb)
                        .addComponent(listadoTa, javax.swing.GroupLayout.PREFERRED_SIZE, 368, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(26, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(listadoLb)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(listadoTa)
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(mostrarBt, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(salirBt, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(34, 34, 34))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(7, 7, 7)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void codigoTfActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_codigoTfActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_codigoTfActionPerformed

    private void salirBtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_salirBtActionPerformed
        System.exit(0);
    }//GEN-LAST:event_salirBtActionPerformed

    private void insertarBtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_insertarBtActionPerformed

        //Objeto de la clase fichero con el método insertarProducto pasandole los parámetros que se encuentra en lo TextField
        f.insertarProducto(codigoTf.getText(), nombreTf.getText(), cantidadTf.getText(), descripcionTf.getText());

        reset();

    }//GEN-LAST:event_insertarBtActionPerformed

    private void mostrarBtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mostrarBtActionPerformed

        f.leerFichero();
        listadoTextArea.setText("");
        for (int i = 0; i < f.getarrayGestion().size(); i++) {
            listadoTextArea.append(f.getarrayGestion().get(i).toString());
            listadoTextArea.append("\n");
        }

    }//GEN-LAST:event_mostrarBtActionPerformed

    private void buscarBtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buscarBtActionPerformed
        f.leerFichero();
        try {

            if (codigoTf.getText() == null || codigoTf.getText().equals("")) {
                JOptionPane.showMessageDialog(null, "El campo del código está en blanco.\nPor favor introduce un codigo para poder buscar el producto",
                        "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            for (int i = 0; i < f.getarrayGestion().size(); i++) {
                if (f.getarrayGestion().get(i).getCodigo().equals(codigoTf.getText())) {
                    nombreTf.setText(f.getarrayGestion().get(i).getNombre());
                    cantidadTf.setText(f.getarrayGestion().get(i).getCantidad());
                    descripcionTf.setText(f.getarrayGestion().get(i).getDescripcion());
                }
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "SE HA PRODUCIDO UN ERROR",
                    "ERROR", JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_buscarBtActionPerformed

    private void nombreTfActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nombreTfActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_nombreTfActionPerformed

    private void modificarBtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_modificarBtActionPerformed
        f.leerFichero();

        String msgError = null;
        try {
            if (codigoTf.getText() == null || codigoTf.getText().equals("")) {
                msgError = "Tienes que indicar el CODIGO para poder modificar el ";
            } else if (nombreTf.getText() == null || nombreTf.getText().equals("")) {
                msgError = "Te has dejado el NOMBRE sin informar";
            } else if (cantidadTf.getText() == null || cantidadTf.getText().equals("")) {
                msgError = "Te has dejado la CANTIDAD sin informar";
            } else if (descripcionTf.getText() == null || descripcionTf.getText().equals("")) {
                msgError = "Te has dejado la DESCRIPCIÓN sin informar";
            }

            if (msgError != null) {
                JOptionPane.showMessageDialog(null, msgError,
                        "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            f.modificarProducto(codigoTf.getText(), nombreTf.getText(), cantidadTf.getText(), descripcionTf.getText());

            JOptionPane.showMessageDialog(null, "Se ha modificado correctamente",
                    "ÉXITO", JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "SE HA PRODUCIDO UN ERROR",
                    "ERROR", JOptionPane.ERROR_MESSAGE);
        }

    }//GEN-LAST:event_modificarBtActionPerformed

    private void borrarBtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_borrarBtActionPerformed
        f.borrarProducto(codigoTf.getText());
        reset();
    }//GEN-LAST:event_borrarBtActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(JuanCarlosFilterMartin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(JuanCarlosFilterMartin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(JuanCarlosFilterMartin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(JuanCarlosFilterMartin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new JuanCarlosFilterMartin().setVisible(true);
            }
        });
    }

    public void reset() {
        codigoTf.setText(null);
        nombreTf.setText(null);
        cantidadTf.setText(null);
        descripcionTf.setText(null);
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton borrarBt;
    private javax.swing.JButton buscarBt;
    private javax.swing.JLabel cantidadLb;
    private javax.swing.JTextField cantidadTf;
    private javax.swing.JLabel codigoLb;
    private javax.swing.JTextField codigoTf;
    private javax.swing.JLabel descripcionLb;
    private javax.swing.JTextField descripcionTf;
    private javax.swing.JButton insertarBt;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JLabel listadoLb;
    private javax.swing.JScrollPane listadoTa;
    private javax.swing.JTextArea listadoTextArea;
    private javax.swing.JButton modificarBt;
    private javax.swing.JButton mostrarBt;
    private javax.swing.JLabel nombreLb;
    private javax.swing.JTextField nombreTf;
    private javax.swing.JButton salirBt;
    // End of variables declaration//GEN-END:variables
}
