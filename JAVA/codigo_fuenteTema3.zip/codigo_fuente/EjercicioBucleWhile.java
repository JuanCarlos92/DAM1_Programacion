
package ejerciciobuclewhile;

public class EjercicioBucleWhile {

    public static void main(String[] args) {
        
        System.out.println("***** Primera Parte ***** ");
        int numero = 1;
        while (numero <= 10) { //bucle que cuenta hasta 10
            System.out.println(numero);
            numero++;
        }
        
        System.out.println("***** Segunda Parte ***** ");
        int numero2 = 10;
        while (numero2 >= 0) { //bucle que cuenta hasta 0
            System.out.println(numero2);
            numero2--;
        }
    }
}

