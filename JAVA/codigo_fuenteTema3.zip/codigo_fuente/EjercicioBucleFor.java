
package ejerciciobuclefor;

public class EjercicioBucleFor {

    public static void main(String[] args) {
        
        System.out.println("***** Primera Parte ***** ");
        for (int numero=1; numero<=10; numero++){
            System.out.println(numero);
        }
        
        System.out.println("***** Segunda Parte ***** ");
        for (int numero = 10; numero >=0; numero--){
            System.out.println(numero);
        }
    }
}

