package prg8;

public class RecorrerElementosDeArray {
    public static void main(String[] args) {
        int [] temperaturas = {8,10,15,20,35,9,13,7,4,21,14,19};
        
        for(int i=0; i<temperaturas.length; i++){
            System.out.println(temperaturas[i]);
        }     
    }
}


