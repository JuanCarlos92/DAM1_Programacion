/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clases_y_metodos_abstractos_y_finales;


public class Camion extends Vehiculo {
 	
        public Camion(double cargaMax) {
            // implementación del constructor
        }
 	
        public double calcEficienciaConsumo() {
            // calcula el consumo de combustible de un camión
 	}
        
 	public double calcDistanciaViaje() {
            // calcula la distancia de este viaje por autopista
 	}
 }


