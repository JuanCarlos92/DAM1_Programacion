
package avion;

public class Avion implements objetoVolador{

    public void despegar() {
 	// acelerar hasta despegar
 	// subir el tren de aterrizaje
    }
    public void aterrizar() {
        // bajar el tren de aterrizaje
        // decelerar y desplegar flaps hasta tocar tierra
        // frenar
    }
    public void volar() {
         // mantener los motores en marcha
    }
    public static void main(String[] args) {
        // TODO code application logic here
    }
}




