
package avion;

public interface objetoVolador {
    
    public abstract void despegar();
    public abstract void aterrizar();
    public abstract void volar();
    
}


