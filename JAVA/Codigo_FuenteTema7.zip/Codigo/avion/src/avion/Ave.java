/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package avion;

/**
 *
 * @author pcr
 */
public class Ave extends animal implements objetoVolador{

    public void despegar() {
 	// acelerar hasta despegar
 	// subir el tren de aterrizaje
    }
    
    public void aterrizar() {
        // bajar el tren de aterrizaje
        // decelerar y desplegar flaps hasta tocar tierra
        // frenar
    }
    
    public void volar() {
         // mantener los motores en marcha
    }
    
    public void hacerNido() {
         // comportamiento de nidificación 
    }
    
    public void ponerHuevos() {
         // implementación de puesta de huevos 
    }
    
    public void comer() {
         // sobrescritura de la acción de comer 
    }
}
